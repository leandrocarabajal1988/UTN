#include <iostream>
#include "creditos.h"
#include "funciones_accesorios.h"


using namespace std;

int creditos(){

    system("cls");
    cout <<endl<<endl;
    cout<<"\t\t";
    string text="LOGRE HACERLOOOOOOOOOOOOOOOOO, LETRA POR LETRA!!!!";
    texto_letras(text, 50000);
    cout<< endl;
    system("pause");


}

