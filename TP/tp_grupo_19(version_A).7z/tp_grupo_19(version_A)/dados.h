//aca va la declaracion de las funciones de lo relacionado a los dados
#pragma once


int tirar_dado();//me devuelve el numero que salio en un dado
void tirar_dados_sombra(int posx, int posy, int cantidad_dados, int vcantidad_dados[]);
void tirar_dados_sin_sombra(int posx, int posy, int cantidad_dados, int vcantidad_dados[]);


