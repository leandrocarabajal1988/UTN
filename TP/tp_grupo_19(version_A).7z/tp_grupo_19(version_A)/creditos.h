#pragma once
#include <string>
#include <unistd.h>

using namespace std;

int creditos();
void texto_letras(string text, int delay);