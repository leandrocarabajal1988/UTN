//aca va la declaracion de las funciones
#pragma once

int seleccionar_Opcion();//es el menu

void opcion_Elegida(int opcion);//entro a la opcion elegida



