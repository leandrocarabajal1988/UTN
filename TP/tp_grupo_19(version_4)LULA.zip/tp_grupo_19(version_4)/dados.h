//aca va la declaracion de las funciones de lo relacionado a los dados
#pragma once


int tirar_dado();//me devuelve el numero que salio en un dado


