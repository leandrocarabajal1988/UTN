//aca va la declaracion de las funciones
#pragma once

int seleccionar_Opcion();//es el menu

void opcion_Elegida(int opcion);//entro a la opcion elegida

void mostrarmenu(const char text, int x, int z, bool seleccion)

