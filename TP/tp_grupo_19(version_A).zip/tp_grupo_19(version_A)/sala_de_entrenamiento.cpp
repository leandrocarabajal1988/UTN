#include "un_jugador.h"
#include "dados.h"
#include <conio.h>
#include <iostream>
#include <string.h>
#include "rlutil.h"
#include "funciones_accesorios.h"

using namespace std;

int sala_de_entrenamiento(){
system("cls");


/*armar_cuadro(23, 2, 94, 10, "BLACK", "GREY");*/



rlutil::locate(100, 38);
system("pause");
return 0;

}

