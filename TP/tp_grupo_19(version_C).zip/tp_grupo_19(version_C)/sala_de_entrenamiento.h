//menu oculto para probar funciones
#pragma once


int sala_de_entrenamiento();

