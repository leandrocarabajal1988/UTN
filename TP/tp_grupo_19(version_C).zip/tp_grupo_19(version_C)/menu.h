//aca va la declaracion de las funciones
#pragma once
#include <iostream>



int seleccionar_Opcion();//es el menu

void opcion_Elegida(int opcion);//entro a la opcion elegida
void texto_letras(std::string text, int delay);



