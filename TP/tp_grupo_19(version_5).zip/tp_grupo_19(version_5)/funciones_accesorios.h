//aca va la declaracion de funciones anexos
#pragma once
#include <string.h>
#include <unistd.h>

void puntos_suspensivos(string texto, int cantidad, int segundos);
void pensando(int tiempo);
